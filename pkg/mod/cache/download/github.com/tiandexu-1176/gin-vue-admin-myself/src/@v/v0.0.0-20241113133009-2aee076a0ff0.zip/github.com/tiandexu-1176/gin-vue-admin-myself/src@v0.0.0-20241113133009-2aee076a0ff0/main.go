package main

import (
	"github.com/tiandexu-1176/gin-vue-admin-myself/src/server/initialize"
)

func main() {

	initialize.Redis()
}
